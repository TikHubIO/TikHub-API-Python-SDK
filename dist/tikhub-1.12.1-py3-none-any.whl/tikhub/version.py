# tikhub/version.py
version = "1.12.1"
