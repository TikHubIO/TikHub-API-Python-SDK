# tikhub/version.py
version = "1.11.9"
